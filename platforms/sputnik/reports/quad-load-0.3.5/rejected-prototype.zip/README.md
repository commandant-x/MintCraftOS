# Prototype rejeté

Freinage vertical renforcé en permanence. Référence native LuaJ : 22/24, translations left/right dépassant 42 degrés. La version finale conserve le gain précédent sans effort extérieur significatif. Cette archive n’est pas un TXT à importer ; ses 24 mouvements complets et sources gelées conservent la régression détectée. Les autres montages de ce prototype ont été interrompus, et ne sont pas annoncés validés.
