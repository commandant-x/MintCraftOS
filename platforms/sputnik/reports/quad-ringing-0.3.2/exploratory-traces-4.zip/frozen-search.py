import sys,importlib.util,json,csv,subprocess,concurrent.futures,time,hashlib
from pathlib import Path
root=Path('/workspace/MintCraftOS');sys.path.insert(0,str(root/'tools'))
from quad_campaign_contract import fixtures,MOVEMENTS,evaluate
spec=importlib.util.spec_from_file_location('b',root/'tools/build-sputnik.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
spec=importlib.util.spec_from_file_location('r',root/'tools/run-sputnik-quad-campaign.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
out=Path('/tmp/sputnik-ringing-033/fourth');out.mkdir(exist_ok=True);base=b.native_quad_fpv();(out/'baseline.lua').write_text(base)
aliases={name:'_'+str(i) for i,name in enumerate(['Portable','Geometry','Physics','Response','Progress','Filter','Vehicle','Mission','Calibration','Flight'])};aliases.update({name:'_'+chr(65+i) for i,name in enumerate(['worldAx','worldAz','desiredYaw','worldRate','requestedSpeed','provisional'])})
fs=[f for f in fixtures() if f['id'] in ('reference','light-16kg','modular-24','slow-radio','very-low-inertia','telemetry-delay')]
cases=['cold-hover','recovery-diagonal','brake','climb','forward-left','load-swing']
variants={}
old='self.quant.verticalFast=(command.vertical~=0 or math.abs(v.y)>.3) and not recovering'
variants['latched-vertical']=base.replace(old,'self.quant.verticalFast=(command.vertical~=0 or self.quant.verticalFast and math.abs(v.y)>.1) and not recovering')
variants['smooth-vertical']=base.replace(old,'self.quant.verticalFast=not recovering and (command.vertical~=0 and 1 or math.min(1,math.abs(v.y)/(cfg.climb or 4))) or 0').replace('(quant.verticalFast and 3 or 1)','(1+2*(quant.verticalFast or 0))')
variants['hysteresis-vertical']=base.replace(old,'self.quant.verticalFast=(command.vertical~=0 or math.abs(v.y)>(self.quant.verticalFast and .1 or 1)) and not recovering')
results=[]
def run(pair):
 name,text=pair;controller=out/name/'controller.lua';controller.parent.mkdir(exist_ok=True)
 c=b.compact(text,aliases,keep_lines=False,private_identifiers=True,explicit_methods=True);controller.write_text(c)
 rr=[]
 for f in fs:
  folder=out/name/f['id'];folder.mkdir(exist_ok=True)
  cfg=dict(fixture=f,seconds=60,cases=cases,controller=str(controller),defaults=str(root/'platforms/sputnik/src/vehicle_model.lua'),pressure=str(root/'platforms/sputnik/tests/fixtures/sable-pressure.csv'),output=str(folder),tilt=20)
  boot=folder/'boot.lua';boot.write_text('MINTCRAFT_CAMPAIGN='+r.lua(cfg)+"\ndofile('tools/sputnik-quad-campaign.lua')\n")
  with (folder/'runtime.log').open('w') as log:subprocess.run(['/workspace/.mintcraft-setup/lua/usr/bin/lua5.2',str(boot)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  for e in csv.DictReader((folder/'events.csv').open()):
   p=folder/(e['case']+'.csv');rows=r.read_trace(p);score=evaluate(rows,e,e['case'],60)
   # Strictly additional transient diagnostic, never overwrite historical acceptance labels.
   phase=10 if e['case'] in ('brake','climb','forward-left') else 5 if e['case'] in ('recovery-diagonal','load-swing') else 0
   bad=[i for i,x in enumerate(rows) if x['t']>=phase and not (abs(x['y']-x['target_y'])<.3 and x['attitude_error']<2 and abs(x['vy'])<.2 and (e['case'] not in ('brake','forward-left') or (x['vx']**2+x['vz']**2)**.5<.3))]
   idx=bad[-1]+1 if bad else next((i for i,x in enumerate(rows) if x['t']>=phase),len(rows))
   settled=rows[idx]['t']-phase if idx<len(rows)-20 else None
   rr.append(dict(fixture=f['id'],movement=e['case'],**score,settling_seconds=settled))
 total=sum(x['status']=='PASS' for x in rr);print(name,total,'/',len(rr),'height',round(sum(x['metrics'].get('transient_height_peak',0) for x in rr),2),flush=True)
 return dict(name=name,modified_utf8_bytes=b.nbt_utf8_size(c),sha256=hashlib.sha256(c.encode()).hexdigest(),passed=total,results=rr)
start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for x in pool.map(run,variants.items()):results.append(x);(out/'search-results.json').write_text(json.dumps(results,indent=2))
print('WALL',time.time()-start)
