import sys,json,subprocess,csv,concurrent.futures,math,hashlib,copy,time
from pathlib import Path
root=Path('/workspace/MintCraftOS');sys.path.insert(0,str(root/'tools'))
from quad_campaign_contract import fixtures,evaluate
import importlib.util
spec=importlib.util.spec_from_file_location('runner',root/'tools/run-sputnik-quad-campaign.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
out=Path('/tmp/sputnik-ringing-033/native-correct');out.mkdir(exist_ok=True)
source=(root/'tools/sputnik-quad-campaign.lua').read_text();old='q={1,0,0,0},omega={0,0,0}'
assert source.count(old)==1
source=source.replace(old,'q=fixture.initialQ and {fixture.initialQ[1],fixture.initialQ[2],fixture.initialQ[3],fixture.initialQ[4]} or {1,0,0,0},omega={0,0,0}')
plant=out/'plant.lua';plant.write_text(source)
controller=root/'platforms/sputnik/dist/mintcraft-autopilot-quad-fpv.lua'
jobs=[]
for base in fixtures():
 if base['id'] not in ('reference','modular-24','slow-radio'):continue
 for rpm in (256,128,64):
  for degrees in (0,3):
   f=copy.deepcopy(base);f['id']+=f'-rpm{rpm}-tilt{degrees}'
   for g in f['rotors']:g['source']=rpm
   half=math.radians(degrees)/2;f['initialQ']=[math.cos(half),math.sin(half)/math.sqrt(2),0,math.sin(half)/math.sqrt(2)]
   jobs.append(f)
cases=['hover','cold-hover','brake','recovery-diagonal']
java='/workspace/.mintcraft-setup/jdk/usr/lib/jvm/java-21-openjdk-amd64/bin/java'
classpath='/tmp/mintcraft-quad-032:/tmp/mintcraft-quad-032/runtime.jar'
meta=dict(schema=1,controller_sha256=hashlib.sha256(controller.read_bytes()).hexdigest(),plant_sha256=hashlib.sha256(plant.read_bytes()).hexdigest(),host_sha256='3fd9dac868400905a55164d2c9d74abc2080ae3269ca51e54e1899874945973e',scope='Native LuaJ; declared physical source RPM and small initial tilt; no Minecraft validation',fixtures=jobs,cases=cases,control_hz=20,physics_hz=200)
(out/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(f):
 folder=out/f['id'];folder.mkdir(exist_ok=True)
 cfg=dict(fixture=f,seconds=60,cases=cases,controller=str(controller),defaults=str(root/'platforms/sputnik/src/vehicle_model.lua'),pressure=str(root/'platforms/sputnik/tests/fixtures/sable-pressure.csv'),output=str(folder),tilt=20)
 boot=folder/'bootstrap.lua';boot.write_text('MINTCRAFT_CAMPAIGN='+runner.lua(cfg)+'\n')
 with (folder/'runtime.log').open('w') as log:subprocess.run([java,'-XX:ActiveProcessorCount=1','-XX:+UseSerialGC','-Xmx512m','-cp',classpath,'VerifySputnikLua',str(boot),str(plant)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 rr=[]
 for event in csv.DictReader((folder/'events.csv').open()):
  assert event['status']!='ERROR',event
  path=folder/(event['case']+'.csv');rows=runner.read_trace(path);score=evaluate(rows,event,event['case'],60)
  rr.append(dict(fixture=f['id'],movement=event['case'],**score,trace_sha256=hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None))
 print(f['id'],sum(r['status']=='PASS' for r in rr),'/',len(rr),flush=True)
 return rr
rr=[];start=time.monotonic()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for values in pool.map(run,jobs):rr.extend(values);(out/'results.json').write_text(json.dumps(rr,indent=2)+'\n')
print('Wall',time.monotonic()-start,flush=True)

