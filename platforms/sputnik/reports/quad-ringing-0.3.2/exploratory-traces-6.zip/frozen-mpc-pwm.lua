function M.signals(meta,values,quant)
 local choices={};local target={0,0,0,0,0,0}
 for i,m in ipairs(meta) do
  local g=m.group;local force=values[i]*m.unit
  local shaft=(quant.spool and quant.spool[g.id] or values[i]*m.unit/(g.members*m.thrust*m.pressure)+math.max(0,m.axial)/m.airflow)
  local rpm=force<=0 and 0 or force/(g.members*m.thrust*m.pressure)+math.max(0,m.axial)/m.airflow
  local delta=force-Physics.force(shaft,m.pressure,m.axial,m.thrust,m.airflow)*g.members
  local command=clip(rpm+LEAD*delta/(g.members*m.thrust*m.pressure),0,g.source)
  local signal=Physics.signal(g.source,command)
  choices[i]={math.floor(signal),math.ceil(signal)}
  for j=1,6 do target[j]=target[j]+m.column[j]*values[i] end
 end
 local best,bestCost
 for mask=0,15 do
  local actual={0,0,0,0,0,0};local selected={}
  for i,m in ipairs(meta) do
   local g=m.group;local signal=choices[i][math.floor(mask/2^(i-1))%2+1]
   local rpm=(quant.spool and quant.spool[g.id] or values[i]*m.unit/(g.members*m.thrust*m.pressure)+math.max(0,m.axial)/m.airflow)+(1-(1-m.alpha)^HORIZON)*(Physics.rpm(g.source,signal)-(quant.spool and quant.spool[g.id] or values[i]*m.unit/(g.members*m.thrust*m.pressure)+math.max(0,m.axial)/m.airflow))
   local force=Physics.force(rpm,m.pressure,m.axial,m.thrust,m.airflow)*g.members
   for j=1,6 do actual[j]=actual[j]+m.column[j]*force/math.max(1e-12,m.unit) end
   selected[tostring(g.id)]=signal
  end
  local cost=0
  for j=1,6 do cost=cost+((actual[j]-target[j])/(j<=3 and 1 or .1))^2 end
  if not bestCost or cost<bestCost then best,bestCost=selected,cost end
 end
 quant.error=nil;quant.clipped=false
 return best
end
