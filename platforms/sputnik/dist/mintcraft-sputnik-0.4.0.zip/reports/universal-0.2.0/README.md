# Historical evidence

The immutable sources, measurements and prior reports are available at https://github.com/commandant-x/MintCraftOS/tree/80fe2f7c3150dab1c108a4e5c303be458dc91568/platforms/sputnik/reports/universal-0.2.0 .
